CREATE SCHEMA covid_db
GO

CREATE TABLE covid_db.covid_population
(
    date                    DATE,
    state                   VARCHAR(4),
    city                    VARCHAR(100),
    place_type              VARCHAR(50),
    confirmed               BIGINT,
    deaths                  BIGINT,
    order_for_place         BIGINT,
	is_last                 VARCHAR(10),
	estimated_population_2019      BIGINT,
	city_ibge_code                 BIGINT,
	confirmed_per_100k_inhabitants VARCHAR(50),
    death_rate                     float(30)
)
